#ifndef SHADER_HPP
#define SHADER_HPP

 // return a program

GLuint LoadShaders(const char * vertex_file_pat, const char * fragment_file_pat);


#endif
